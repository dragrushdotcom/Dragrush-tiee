#!/usr/bin/env python3
"""Separate-process SQLite WAL/FULL durable queue surrogate. NOT Redis Streams/Kafka."""
import argparse, hashlib, json, sqlite3, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

def db(path):
    c=sqlite3.connect(path,timeout=30,isolation_level=None)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA synchronous=FULL')
    c.execute('PRAGMA busy_timeout=30000')
    c.execute('CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, rounds INTEGER NOT NULL, status TEXT NOT NULL, lease_until REAL NOT NULL DEFAULT 0, attempt INTEGER NOT NULL DEFAULT 0, digest TEXT, published REAL NOT NULL, completed REAL)')
    c.execute('CREATE TABLE IF NOT EXISTS decisions (id TEXT PRIMARY KEY, disposition TEXT NOT NULL, reason TEXT NOT NULL, created REAL NOT NULL, fingerprint TEXT)')
    cols={x[1] for x in c.execute('PRAGMA table_info(decisions)')}
    if 'fingerprint' not in cols: c.execute('ALTER TABLE decisions ADD COLUMN fingerprint TEXT')
    return c

def make_handler(path,max_pending=12):
  class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args): pass
    def reply(self,status,obj):
        b=json.dumps(obj,separators=(',',':')).encode(); self.send_response(status); self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def post(self):
        n=int(self.headers.get('Content-Length','0'))
        if n<0 or n>4096: return self.reply(413,{'error':'oversized'})
        try: v=json.loads(self.rfile.read(n))
        except (ValueError,UnicodeDecodeError): return self.reply(400,{'error':'bad_json'})
        c=db(path)
        try:
            op=urlsplit(self.path).path
            if op=='/publish':
                ident=v['id'];payload=v['payload']; rounds=v['rounds'];mode=v['mode']
                if not isinstance(ident,str) or len(ident)>100 or not isinstance(payload,str) or len(payload)>2000 or not isinstance(rounds,int) or not 0<=rounds<=100000 or mode not in ('conventional','tiee'):
                    return self.reply(400,{'error':'bad_input'})
                if not isinstance(v.get('p_valid',0.8),(int,float)) or not 0<=v.get('p_valid',0.8)<=1: return self.reply(400,{'error':'bad_probability'})
                # Canonical request fingerprint covers rejected as well as accepted event identities.
                canonical=json.dumps({'payload':payload,'rounds':rounds,'mode':mode,'p_valid':v.get('p_valid',0.8)},sort_keys=True,separators=(',',':'),ensure_ascii=False)
                fingerprint=hashlib.sha256(canonical.encode('utf-8')).hexdigest()
                reject=payload.startswith('bot-')
                # The original EV sign check is an additional decision only; not allowed to reject useful events in this synthetic test.
                if mode=='tiee' and not reject:
                    p=float(v.get('p_valid',0.8))
                    reject=(p-(1-p))<=0
                disposition='REJECT' if reject else 'ALLOW'
                c.execute('BEGIN IMMEDIATE')
                existing=c.execute('SELECT disposition,fingerprint FROM decisions WHERE id=?',(ident,)).fetchone()
                if existing:
                    # Refuse ambiguous duplicates from legacy decisions without a fingerprint.
                    if existing[1] is None or existing[1]!=fingerprint: c.rollback();return self.reply(409,{'error':'id_conflict'})
                    c.commit();return self.reply(200,{'disposition':existing[0],'duplicate':True})
                if disposition=='ALLOW':
                    pending=c.execute("SELECT count(*) FROM events WHERE status!='done'").fetchone()[0]
                    if pending>=max_pending:
                        c.rollback()  # No admission record or dedup key is consumed.
                        return self.reply(429,{'error':'backpressure','retryable':True})
                c.execute('INSERT INTO decisions(id,disposition,reason,created,fingerprint) VALUES(?,?,?,?,?)',(ident,disposition,'deterministic-prefix-or-ev' if reject else 'accepted',time.time(),fingerprint))
                if not reject: c.execute('INSERT INTO events(id,payload,rounds,status,published) VALUES(?,?,?,?,?)',(ident,payload,rounds,'ready',time.time()))
                c.commit() # FULL WAL commit before HTTP 201
                return self.reply(201,{'disposition':disposition,'durable':True})
            if op=='/claim':
                lease=float(v.get('lease_seconds',3.0));lease=max(0.1,min(30.,lease))
                c.execute('BEGIN IMMEDIATE')
                row=c.execute("SELECT id,payload,rounds,attempt FROM events WHERE status='ready' OR (status='leased' AND lease_until<?) ORDER BY published,id LIMIT 1",(time.time(),)).fetchone()
                if row:
                    c.execute("UPDATE events SET status='leased',lease_until=?,attempt=attempt+1 WHERE id=?",(time.time()+lease,row[0]))
                c.commit()
                return self.reply(200,{'event':{'id':row[0],'payload':row[1],'rounds':row[2],'attempt':row[3]+1} if row else None})
            if op=='/ack':
                ident=v['id'];digest=v['digest'];attempt=v['attempt']
                if not isinstance(digest,str) or len(digest)!=64: return self.reply(400,{'error':'bad_digest'})
                c.execute('BEGIN IMMEDIATE')
                row=c.execute('SELECT status,digest,attempt,lease_until FROM events WHERE id=?',(ident,)).fetchone()
                if not row: c.rollback();return self.reply(404,{'error':'missing'})
                if row[0]=='done':
                    if row[1]!=digest: c.rollback();return self.reply(409,{'error':'digest_conflict'})
                    c.commit();return self.reply(200,{'duplicate':True})
                if row[0]!='leased': c.rollback();return self.reply(409,{'error':'not_leased'})
                if not isinstance(attempt,int) or attempt!=row[2] or time.time()>row[3]: c.rollback();return self.reply(409,{'error':'stale_lease'})
                c.execute("UPDATE events SET status='done',digest=?,completed=?,lease_until=0 WHERE id=?",(digest,time.time(),ident))
                c.commit();return self.reply(200,{'committed':True})
            if op=='/stats':
                x=dict(c.execute('SELECT status,count(*) FROM events GROUP BY status').fetchall());d=dict(c.execute('SELECT disposition,count(*) FROM decisions GROUP BY disposition').fetchall());return self.reply(200,{'events':x,'decisions':d})
            return self.reply(404,{'error':'unknown_endpoint'})
        except (sqlite3.Error,ValueError,KeyError,TypeError) as e:
            try:c.rollback()
            except sqlite3.Error:pass
            return self.reply(400,{'error':str(e)[:100]})
        finally:c.close()
    do_POST=post
  return Handler

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--db',required=True);p.add_argument('--port',type=int,required=True);p.add_argument('--max-pending',type=int,default=12);a=p.parse_args()
 if a.max_pending<1: p.error('max-pending must be positive')
 c=db(a.db);c.close();http=ThreadingHTTPServer(('127.0.0.1',a.port),make_handler(a.db,a.max_pending));http.serve_forever()
