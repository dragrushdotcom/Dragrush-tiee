# TiEE Core v4.1 — Identity integrity experiment

This is a narrow correctness increment to the v4.0 SQLite WAL/FULL broker, **not** the promised Redis/Kafka/PostgreSQL deployment.

Each publish decision now stores a SHA-256 fingerprint of the canonical payload, rounds, mode and declared probability. The same event ID and identical request is idempotent after restart, including rejections. A changed request is HTTP 409 for both accepted and rejected events. Legacy decisions missing fingerprints are rejected as ambiguous on replay.

These fingerprints are **not authentication** and client-supplied `p_valid` is still untrusted. No throughput advantage is claimed. Single-machine durability is not a substitute for replicated broker/power-loss guarantees. The v4.0 source remains separately available.
