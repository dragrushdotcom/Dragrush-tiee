import hashlib,json,os,signal,socket,sqlite3,subprocess,tempfile,time,unittest,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def request(port,endpoint,payload):
 b=json.dumps(payload).encode();r=urllib.request.Request(f'http://127.0.0.1:{port}/{endpoint}',data=b,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=8) as f:return f.status,json.loads(f.read())
def digest(p,r):
 v=hashlib.sha256(p.encode()).digest()
 for _ in range(r):v=hashlib.sha256(v).digest()
 return v.hex()
class Recovery(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.db=str(Path(self.tmp.name)/'events.db');s=socket.socket();s.bind(('127.0.0.1',0));self.port=s.getsockname()[1];s.close();self.start()
 def start(self):
  self.proc=subprocess.Popen(['python',str(ROOT/'broker.py'),'--db',self.db,'--port',str(self.port)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  for _ in range(100):
   try:request(self.port,'stats',{});return
   except Exception:time.sleep(.025)
  raise RuntimeError('broker startup failed')
 def crash(self):self.proc.kill();self.proc.wait(timeout=5);self.proc.stderr.close()
 def tearDown(self):
  if self.proc.poll() is None:self.crash()
  self.tmp.cleanup()
 def test_publish_crash_replay_and_ack_idempotence(self):
  event={'id':'one','payload':'legit-hello','rounds':100,'mode':'conventional','p_valid':.8}
  status,resp=request(self.port,'publish',event);self.assertEqual(status,201);self.assertTrue(resp['durable'])
  self.crash();self.start()
  status,claim=request(self.port,'claim',{'lease_seconds':.1});self.assertEqual(claim['event']['id'],'one')
  self.crash();self.start();time.sleep(.15)
  status,claim=request(self.port,'claim',{'lease_seconds':1});self.assertEqual(claim['event']['id'],'one');self.assertEqual(claim['event']['attempt'],2)
  d=digest(event['payload'],event['rounds'])
  with self.assertRaises(urllib.error.HTTPError) as e:request(self.port,'ack',{'id':'one','digest':d,'attempt':1})
  self.assertEqual(e.exception.code,409)
  self.assertEqual(request(self.port,'ack',{'id':'one','digest':d,'attempt':2})[0],200)
  self.assertTrue(request(self.port,'ack',{'id':'one','digest':d,'attempt':2})[1]['duplicate'])
  self.assertTrue(request(self.port,'publish',event)[1]['duplicate'])
  with self.assertRaises(urllib.error.HTTPError) as e:request(self.port,'publish',{**event,'payload':'legit-modified'})
  self.assertEqual(e.exception.code,409)
  c=sqlite3.connect(self.db);self.assertEqual(c.execute("SELECT count(*) FROM events WHERE status='done'").fetchone()[0],1)
 def test_reject_durable_and_no_accepted_loss(self):
  ev={'id':'bot','payload':'bot-traffic','rounds':100,'mode':'tiee','p_valid':.1}
  self.assertEqual(request(self.port,'publish',ev)[1]['disposition'],'REJECT')
  self.crash();self.start()
  self.assertIsNone(request(self.port,'claim',{})[1]['event'])
  self.assertTrue(request(self.port,'publish',ev)[1]['duplicate'])
  for mod in ({'payload':'bot-CHANGED'},{'rounds':101},{'mode':'conventional'},{'p_valid':.2}):
   with self.assertRaises(urllib.error.HTTPError) as err: request(self.port,'publish',{**ev,**mod})
   self.assertEqual(err.exception.code,409)
  c=sqlite3.connect(self.db);self.assertEqual(c.execute("SELECT count(*) FROM decisions WHERE disposition='REJECT'").fetchone()[0],1)
 def test_legacy_decision_cannot_be_silently_reused(self):
  ev={'id':'legacy','payload':'bot-old','rounds':4,'mode':'conventional'}
  self.crash()
  c=sqlite3.connect(self.db);c.execute("INSERT INTO decisions(id,disposition,reason,created,fingerprint) VALUES ('legacy','REJECT','old',0,NULL)");c.commit();c.close()
  self.start()
  with self.assertRaises(urllib.error.HTTPError) as err:request(self.port,'publish',ev)
  self.assertEqual(err.exception.code,409)
if __name__=='__main__':unittest.main()
