import json, sqlite3, urllib.error
from test_recovery import Recovery,request,digest

class Backpressure(Recovery):
 def event(self,ident,payload='legit-data'):
  return {'id':ident,'payload':payload,'rounds':5,'mode':'conventional','p_valid':.8}
 def test_backpressure_retry_reject_during_full(self):
  for i in range(12):
   self.assertEqual(request(self.port,'publish',self.event(str(i)))[0],201)
  with self.assertRaises(urllib.error.HTTPError) as ctx:
   request(self.port,'publish',self.event('next'))
  self.assertEqual(ctx.exception.code,429)
  c=sqlite3.connect(self.db)
  self.assertEqual(c.execute("SELECT count(*) FROM decisions WHERE id='next'").fetchone()[0],0)
  self.assertEqual(c.execute("SELECT count(*) FROM events WHERE status!='done'").fetchone()[0],12)
  c.close()
  # Reject requests never consume the work queue.
  self.assertEqual(request(self.port,'publish',self.event('noise','bot-spam'))[1]['disposition'],'REJECT')
  claim=request(self.port,'claim',{})[1]['event']
  self.assertEqual(request(self.port,'ack',{'id':claim['id'],'digest':digest(claim['payload'],claim['rounds']),'attempt':claim['attempt']})[0],200)
  self.assertEqual(request(self.port,'publish',self.event('next'))[0],201)
  self.crash();self.start()
  self.assertEqual(request(self.port,'publish',self.event('next'))[1]['duplicate'],True)
  with self.assertRaises(urllib.error.HTTPError) as changed:
   request(self.port,'publish',self.event('next','legit-altered'))
  self.assertEqual(changed.exception.code,409)
  stats=request(self.port,'stats',{})[1]
  self.assertEqual(stats['decisions']['ALLOW'],13)
  self.assertEqual(stats['decisions']['REJECT'],1)
