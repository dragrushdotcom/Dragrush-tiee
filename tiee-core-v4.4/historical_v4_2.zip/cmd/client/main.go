package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
 "errors"
	"io"
	"math/rand"
	"net/http"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type Event struct {
	ID      string  `json:"id"`
	Payload string  `json:"payload"`
	Rounds  int     `json:"rounds"`
	Mode    string  `json:"mode"`
	PValid  float64 `json:"p_valid"`
}
type Claim struct {
	Event *struct {
		ID      string `json:"id"`
		Payload string `json:"payload"`
		Rounds  int    `json:"rounds"`
		Attempt int    `json:"attempt"`
	} `json:"event"`
}

func digest(payload string, rounds int) string {
	v := sha256.Sum256([]byte(payload))
	for i := 0; i < rounds; i++ {
		v = sha256.Sum256(v[:])
	}
	return hex.EncodeToString(v[:])
}
type StatusError struct { Code int }
func (e StatusError) Error() string {return fmt.Sprintf("HTTP status %d",e.Code)}
func call(client *http.Client, url string, v any, out any) error {
	b, _ := json.Marshal(v)
	r, e := client.Post(url, "application/json", bytes.NewReader(b))
	if e != nil {
		return e
	}
	defer r.Body.Close()
	if r.StatusCode >= 300 {
		return StatusError{Code:r.StatusCode}
	}
	data, e := io.ReadAll(r.Body)
	if e != nil {
		return e
	}
	return json.Unmarshal(data, out)
}
func percentile(v []float64, p float64) float64 {
	if len(v) == 0 {
		return 0
	}
	sort.Float64s(v)
	return v[int(float64(len(v)-1)*p)]
}
func main() {
	url := flag.String("url", "http://127.0.0.1:18773", "broker")
	mode := flag.String("mode", "conventional", "mode")
	seed := flag.Int64("seed", 1, "seed")
	n := flag.Int("n", 100, "events")
	noise := flag.Float64("noise", 0.7, "noise rate")
	rounds := flag.Int("rounds", 3000, "work rounds")
	workers := flag.Int("workers", 4, "workers")
	flag.Parse()
	if *mode != "conventional" && *mode != "tiee" {
		panic("mode")
	}
	client := &http.Client{Timeout: 15 * time.Second, Transport: &http.Transport{MaxIdleConns: 64, MaxIdleConnsPerHost: 64}}
	r := rand.New(rand.NewSource(*seed))
	events := make([]Event, *n)
	expected := 0
	for i := range events {
		bad := r.Float64() < *noise
		prefix := "legit"
		p := 0.8
		if bad {
			prefix = "bot"
			p = 0.2
		} else {
			expected++
		}
		events[i] = Event{ID: fmt.Sprintf("s%d-%s-%d", *seed, *mode, i), Payload: fmt.Sprintf("%s-%d-%d", prefix, *seed, i), Rounds: *rounds, Mode: *mode, PValid: p}
	}
	r.Shuffle(len(events), func(i, j int) { events[i], events[j] = events[j], events[i] })
	start := time.Now()
	var wg sync.WaitGroup
	sem := make(chan struct{}, 8)
	var mu sync.Mutex
	lat := make([]float64, 0, *n)
	var failed atomic.Int64
	var rejected atomic.Int64
	var completed atomic.Int64
	var stop atomic.Bool
	for j := 0; j < *workers; j++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for !stop.Load() {
				var cl Claim
				err := call(client, *url+"/claim", map[string]any{"lease_seconds": 5}, &cl)
				if err != nil {
					failed.Add(1)
					return
				}
				if cl.Event == nil {
					if completed.Load() >= int64(expected) {
						return
					}
					time.Sleep(4 * time.Millisecond)
					continue
				}
				h := digest(cl.Event.Payload, cl.Event.Rounds)
				var ack map[string]any
				err = call(client, *url+"/ack", map[string]any{"id": cl.Event.ID, "digest": h, "attempt": cl.Event.Attempt}, &ack)
				if err != nil {
					failed.Add(1)
					fmt.Fprintln(os.Stderr, err)
					return
				}
				completed.Add(1)
			}
		}()
	}
	for _, e := range events {
		sem <- struct{}{}
		wg.Add(1)
		go func(e Event) {
			defer wg.Done()
			defer func() { <-sem }()
			t := time.Now()
			var out struct {
				Disposition string `json:"disposition"`
			}
			var err error
            for tries:=0;tries<200;tries++ {
                err=call(client, *url+"/publish", e, &out)
                var httpErr StatusError
                if errors.As(err,&httpErr) && httpErr.Code==429 {
                    time.Sleep(time.Duration(3+tries/8)*time.Millisecond)
                    continue
                }
                break
            }
			mu.Lock()
			lat = append(lat, float64(time.Since(t).Microseconds())/1000)
			mu.Unlock()
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				failed.Add(1)
			} else if out.Disposition == "REJECT" {
				rejected.Add(1)
			}
		}(e)
	}
	wg.Wait()
	publishDone := time.Since(start)
	if failed.Load() > 0 {
		os.Exit(2)
	}
	deadline := time.After(40 * time.Second)
	done := make(chan struct{})
	go func() { wg.Wait(); close(done) }()
	select {
	case <-done:
	case <-deadline:
		stop.Store(true)
		fmt.Fprintln(os.Stderr, "drain timeout")
		os.Exit(3)
	}
	total := time.Since(start)
	if failed.Load() > 0 || int(completed.Load()) != expected || int(rejected.Load()) != *n-expected {
		fmt.Fprintln(os.Stderr, "accounting mismatch", completed.Load(), expected, rejected.Load())
		os.Exit(4)
	}
	stats := map[string]any{}
	if err := call(client, *url+"/stats", map[string]any{}, &stats); err != nil {
		panic(err)
	}
	if int(stats["events"].(map[string]any)["done"].(float64)) != expected {
		panic("durable verification mismatch")
	}
	output := map[string]any{"mode": *mode, "seed": *seed, "events": *n, "useful": expected, "rejected": rejected.Load(), "completed": completed.Load(), "elapsed_s": total.Seconds(), "publish_s": publishDone.Seconds(), "useful_per_s": float64(expected) / total.Seconds(), "publish_p95_ms": percentile(lat, .95), "rounds": *rounds, "noise": *noise, "workers": *workers, "verified": true}
	data, _ := json.Marshal(output)
	fmt.Println(string(data))
	_ = strings.TrimSpace
}
