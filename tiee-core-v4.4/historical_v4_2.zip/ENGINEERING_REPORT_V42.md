# TiEE Core v4.2 — Bounded Admission & Retry Integrity

## Status
Verified experimental extension of v4.1. This is **not** a Redis Streams, Kafka, or PostgreSQL implementation. Local Python HTTP + SQLite WAL/FULL and Go bounded workers only.

## What changed
- Broker option `--max-pending 12` sets the maximum `ready` + `leased` backlog, enforced within the same `BEGIN IMMEDIATE` transaction as durable event decision creation.
- When full, a valid would-be `ALLOW` receives HTTP 429; no decision or idempotency identifier is reserved, so identical retries can succeed once capacity opens.
- Already accepted identical IDs still return a duplicate, and changed payloads return 409, even under saturation. Explicit `REJECT` is durably recorded without consuming work slots.
- Go publisher retries *only* HTTP 429 with bounded backoff; it does not retry arbitrary errors.
- Claimed work retains leased-attempt fencing and idempotent digest acknowledgments.

## Validation
- 24 completed randomized paired benchmark trials (four workloads × three seeds × two policies), each 40 events, 960 total; every allowed result independently SHA256-verified from SQLite data; all disposition counts reconciled.
- 10 Python integration test executions passed (some inherited tests executed twice by subclass inheritance, not 10 unique test contracts); new backpressure case tests full queue, retry after ack, durable rejects, unchanged duplicate IDs and changed-payload conflicts after crash/restart.
- `go build ./cmd/client` and `go test -race ./...` pass; Go package has **no** Go unit test functions.

## Results
Mean paired ratio, TiEE EV / optimized conventional filtered useful throughput:

| Workload | Ratio | Mean EDF useful/s | Mean TiEE useful/s |
| --- | ---: | ---: | ---: |
| Cheap, 20% noise | 1.004× | 44.29 | 44.35 |
| Cheap, 70% noise | 1.021× | 27.30 | 27.94 |
| Expensive, 20% noise | 1.006× | 45.95 | 46.21 |
| Expensive, 70% noise | 1.009× | 28.01 | 28.37 |

Three seeds are far too few for credible comparative significance; no TiEE-specific performance advantage demonstrated. SQLite synchronous writes and retry/backpressure greatly affect total throughput; changes cannot be compared directly to the unbounded v4.1 experiment. Publication p95 latency includes retries and queue waiting and can reach hundreds of milliseconds. There is no separate per-attempt retry-count metric yet.

## Critical limitations / next steps
1. No Redis/Kafka or independent PostgreSQL service available in this environment. Must not substitute these benchmark results for real broker/database evidence.
2. Identity validation remains simplistic; the `p_valid` property is **client-supplied**, not trusted/calibrated. Recognizable `bot-` prefix makes the EV check redundant.
3. Broker assumes trusted localhost clients; no auth/TLS, quotas per tenant, encrypted storage, size-bounded audit history, or fairness under adversarial producers.
4. Server trusts worker-submitted digests; digest is independently validated **by benchmark**, not by the broker on every acknowledgment. At-least-once work, idempotent result commit; no guarantee of exactly-once side effects.
5. 429 transient admission responses are not durable event records; producer responsibility to retry is explicit. Crash/power-failure coverage incomplete.
6. No actual AI inference, measured energy, GPU utilization, 2KB total per-message memory guarantee, or demonstrated TiEE original 20×/36.8% claims.

Next: real broker/Postgres infrastructure where available, signed provenance, independent authorization/verification, fairness under saturation, real expensive inference and equal-resource baseline.
