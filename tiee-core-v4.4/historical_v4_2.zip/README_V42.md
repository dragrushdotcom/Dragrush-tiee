# TiEE Core v4.2 experimental bounded-admission bridge

Go 1.23+ and Python 3.11+ standard library. This is **not** real Redis/Kafka or PostgreSQL.

## Verify

```sh
python -m unittest discover -s tests -v
go test -race ./...
go build -o client ./cmd/client
python benchmark.py
```

`benchmark.py` saves full SQLite ledgers and `results/trials.csv`, `results/summary.json`; it needs a local loopback HTTP listener. Brokers started with `--max-pending 12` by default and all policies share it.

The v4.1 archive is preserved as `historical_v4_1.zip`.
