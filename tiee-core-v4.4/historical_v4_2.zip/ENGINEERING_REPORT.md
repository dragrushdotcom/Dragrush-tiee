# TiEE Core v4.1 — Identity Integrity & Durable Replay

**Status:** Experimental, SQLite-backed broker bridge; Redis/Kafka/Postgres not installed.

This version closes a v4.0 data-integrity failure: previously rejected event IDs now bind to canonical request SHA-256 fingerprints. Repeated identical publish requests return idempotent duplicate acknowledgment; changed content, rounds, mode, or probability are rejected as conflicts after restart. Legacy rows with no fingerprint are not silently accepted.

## Executed verification
- 3 Python integration/recovery tests passed, including hard broker kill/restart, stale lease fencing, rejected ID conflicts, legacy row conflict.
- Go 1.23 build succeeded; `go test -race ./...` finished but there are **no Go unit tests**, so this is a build check rather than a claim of race-test coverage.
- 24 short matched trials, four synthetic scenarios × three seeds × conventional/TiEE, each with 40 events; 960 source events total. Downstream SHA work verified by the benchmark using persisted digests.
- Throughput is not statistically established as different, n=3 pairs each. Mean paired TiEE/conventional ratios:
  - cheap20: 1.004×
  - cheap70: 1.055×
  - expensive20: 0.994×
  - expensive70: 0.973×

## Limitations
This is not production security or high availability: no authentication, request signing, TLS, independent Kafka/Redis stream, PostgreSQL, power-off test, realistic classifier, GPU inference, formal EV calibration, or full process memory/p95-p99 accounting. Client-provided p_valid remains untrusted and the redundant EV check has no demonstrated architectural benefit. Single-machine SQLite WAL/FULL storage only. The previous v4.0 release remains preserved.
