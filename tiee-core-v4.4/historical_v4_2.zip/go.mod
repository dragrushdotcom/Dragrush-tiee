module tiee-v40

go 1.23
