# TiEE Core v4.1 — Identity Integrity Pilot (Experimental)

This is an **additive partial implementation** of the book's Gateway → Grand Gallery → King's Chamber execution path. It is not Redis Streams, Kafka, or PostgreSQL, and is not a production release.

## Components
- `broker.py`: separate Python HTTP process, SQLite WAL + `synchronous=FULL`; transactional admission/decision journal, persistent queue, lease claims, idempotent ack and result digest.
- `cmd/client/main.go`: Go HTTP event publisher and 4-worker pool; SHA-256 simulated work, final digest ack, concurrent publish and processing.
- `tests/test_recovery.py`: broker hard kill/restart before claim and after claim, lease expiration and stale worker rejection, idempotent replay, conflict detection, durable rejection.
- `benchmark.py`: equal-resource comparison conventional deterministic prefix filtering versus same filter + original EV sign check, identical event sets and downstream work. Independent SQLite digest and decision verification.

## Run
```sh
cd TiEE_Core_v4_0_SQLite_Durable_Pipeline
go build -o client ./cmd/client
python -m unittest discover -s tests -v
python benchmark.py
```
Only Python standard library and Go 1.23 required. `benchmark.py` uses 24 independent process/database instances, 4 scenarios × 3 seeds × 2 policies × 40 events. The broker is bound to loopback.

## Critical limitations
- SQLite durable queue is a *surrogate*, not a real Redis/Kafka broker or PostgreSQL King's Chamber.
- `p_valid` is client-supplied and not trusted or calibrated. This synthetic EV sign check is intentionally redundant with deterministic filtering.
- Artificial `bot-` prefix makes noise perfectly identifiable; real false-positive rates are untested.
- Processing is at-least-once; a worker may execute twice if it crashes before committing ack. Final output is idempotently committed once per ID, but external side effects require separate protection.
- The broker serializes SQLite write transactions, creating a performance bottleneck; this benchmark is not a comparison against a production optimized streaming stack.
- Benchmarks use 40-event samples and three seeds per scenario, insufficient for reliable performance claims. No GPU, real inference, memory peak, power, or SOC16 evaluation.
- Crash tests use kill/restart but not storage power-loss fault injection or multi-node replication.
- Duplicate rejected ID payload conflicts are not checked against original payload; tighten this before external use.

## v4.1 changes
See `ENGINEERING_REPORT.md` and `V4_1_SCOPE.md`.
