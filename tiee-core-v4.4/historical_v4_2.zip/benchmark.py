import csv,hashlib,json,os,random,resource,socket,sqlite3,subprocess,time,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
rows=[]
scenarios=[('cheap20',200,.2),('cheap70',200,.7),('expensive20',6000,.2),('expensive70',6000,.7)]
for scenario,rounds,noise in scenarios:
 for seed in range(1,4):
  modes=['conventional','tiee'];random.Random(seed).shuffle(modes)
  for mode in modes:
   path=OUT/f'{scenario}_{seed}_{mode}.sqlite';path.unlink(missing_ok=True)
   for ext in ('-wal','-shm'):(OUT/(path.name+ext)).unlink(missing_ok=True)
   s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
   broker=subprocess.Popen(['python',str(ROOT/'broker.py'),'--db',str(path),'--port',str(port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   try:
    for _ in range(200):
     try:
      import urllib.request
      b=b'{}';urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}/stats',data=b),timeout=1).close();break
     except Exception:time.sleep(.02)
    else:raise RuntimeError('broker unavailable')
    start=time.monotonic()
    cmd=[str(ROOT/'client'),'-url',f'http://127.0.0.1:{port}','-mode',mode,'-seed',str(seed),'-n','40','-noise',str(noise),'-rounds',str(rounds)]
    x=subprocess.run(cmd,capture_output=True,text=True,timeout=50)
    if x.returncode:raise RuntimeError(f'client failed {x.stderr}')
    row=json.loads(x.stdout.strip());row['scenario']=scenario;row['full_wall_s']=time.monotonic()-start
    # independently check persisted output digest, decisions, completeness and zero duplicates
    c=sqlite3.connect(path)
    allrows=c.execute('SELECT id,payload,rounds,digest,status FROM events').fetchall()
    for ident,payload,rr,digest,status in allrows:
     v=hashlib.sha256(payload.encode()).digest()
     for _ in range(rr):v=hashlib.sha256(v).digest()
     assert status=='done' and v.hex()==digest,(ident,status)
    d=dict(c.execute('SELECT disposition,count(*) FROM decisions GROUP BY disposition').fetchall())
    assert d.get('ALLOW',0)==row['useful'] and d.get('REJECT',0)==row['rejected'] and sum(d.values())==40
    assert len(allrows)==row['useful'];row['db_bytes']=path.stat().st_size;row['independent_verify']=True
    c.close();rows.append(row)
    print(f'{scenario} seed={seed} {mode}: {row["useful_per_s"]:.1f} useful/s p95={row["publish_p95_ms"]:.1f}ms',flush=True)
   finally:
    broker.kill();broker.wait(timeout=5)
fields=list(rows[0]);withfile=OUT/'trials.csv'
with open(withfile,'w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
summary={}
for scenario,_,_ in scenarios:
 a={r['seed']:r for r in rows if r['scenario']==scenario and r['mode']=='conventional'}
 b={r['seed']:r for r in rows if r['scenario']==scenario and r['mode']=='tiee'}
 ratios=[b[s]['useful_per_s']/a[s]['useful_per_s'] for s in sorted(a)]
 summary[scenario]={'tiee_to_conventional_mean_paired_ratio':statistics.mean(ratios),'paired_ratios':ratios,'conventional_mean_useful_s':statistics.mean(x['useful_per_s'] for x in a.values()),'tiee_mean_useful_s':statistics.mean(x['useful_per_s'] for x in b.values())}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
